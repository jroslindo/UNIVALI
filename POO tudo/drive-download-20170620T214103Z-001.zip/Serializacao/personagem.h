#ifndef PERSONAGEM_H
#define PERSONAGEM_H
#include <iostream>
using namespace std;

#include "item.h"
#include <vector>
class Personagem
{
private:
    string nome;
    int nivel;
    vector <Item> mochila;
    Item maoEsq;
    Item maoDir;
    Item cabeca;
    Item armadura;
public:
    Personagem();


    string getNome() const;
    void setNome(const string &value);
    int getNivel() const;
    void setNivel(int value);
    Item getMaoDir() const;
    void setMaoDir(const Item &value);
    Item getMaoEsq() const;
    void setMaoEsq(const Item &value);
    Item getCabeca() const;
    void setCabeca(const Item &value);
    Item getArmadura() const;
    void setArmadura(const Item &value);

    bool adicionarItem (Item x);
    void removerItem (int pos);
    Item getItem(int pos);
    void salvar();
    void carregar(string nome);
    int qtdItens();
};

#endif // PERSONAGEM_H
