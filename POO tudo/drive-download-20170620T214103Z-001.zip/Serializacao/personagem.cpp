#include "personagem.h"
#include <fstream>
#include <cstring>

string Personagem::getNome() const
{
    return nome;
}

void Personagem::setNome(const string &value)
{
    nome = value;
}

int Personagem::getNivel() const
{
    return nivel;
}

void Personagem::setNivel(int value)
{
    nivel = value;
}

Item Personagem::getMaoDir() const
{
    return maoDir;
}

void Personagem::setMaoDir(const Item &value)
{
    maoDir = value;
}

Item Personagem::getMaoEsq() const
{
    return maoEsq;
}

void Personagem::setMaoEsq(const Item &value)
{
    maoEsq = value;
}

Item Personagem::getCabeca() const
{
    return cabeca;
}

void Personagem::setCabeca(const Item &value)
{
    cabeca = value;
}

Item Personagem::getArmadura() const
{
    return armadura;
}

void Personagem::setArmadura(const Item &value)
{
    armadura = value;
}

Personagem::Personagem()
{

}


bool Personagem::adicionarItem (Item x){
    if (mochila.size() < 10){
        mochila.push_back(x);
        return true;
    }else{
        cout << "\nmochila cheia";
        return false;
    }
}

void Personagem::removerItem (int pos){
    mochila.erase(mochila.begin()+pos);
}

Item Personagem::getItem(int pos){
    return mochila[pos];
}

void Personagem::salvar(){
    ofstream saida;
    saida.open(nome + ".save", ios::binary);
    char auxiliar[256];
    //gravando nome
    strcpy(auxiliar, nome.c_str());
    auxiliar[nome.size()] ='\0';

    saida.write(reinterpret_cast <char *> (&auxiliar), sizeof (char)*256);

    // gravando nivel
    saida.write(reinterpret_cast <char *> (&nivel), sizeof (int));

    //salvar a mochila
    int qtd = mochila.size();
    saida.write(reinterpret_cast <char *> (&qtd), sizeof (int));

    for(Item x: mochila){
        strcpy(auxiliar, x.getDescricao().c_str());
        auxiliar[x.getDescricao().size()] = '\0';
        saida.write(reinterpret_cast <char *> (&auxiliar), sizeof(char)*256);

        float poder =x.getPoder();
        saida.write(reinterpret_cast <char *> (&poder), sizeof (float));
    }

    //salvando cabeca
    strcpy(auxiliar, getCabeca().getDescricao().c_str());
    auxiliar[getCabeca().getDescricao().size()] = '\0';
    saida.write(reinterpret_cast <char *> (&auxiliar), sizeof(char)*256);

    float poder =getCabeca().getPoder();
    saida.write(reinterpret_cast <char *> (&poder), sizeof (float));
    /*
    //salvando mao direita
    strcpy(auxiliar, getMaoDir().getDescricao().c_str());
    auxiliar[getCabeca().getDescricao().size()] = '\0';
    saida.write(reinterpret_cast <char *> (&auxiliar), sizeof(char)*256);

    float poder =getCabeca().getPoder();
    saida.write(reinterpret_cast <char *> (&poder), sizeof (float));
*/
    saida.close();
}


void Personagem::carregar(string nome){
    ifstream entrada;

    entrada.open(nome +".save", ios :: binary);

    if (!entrada){
        cout << "Erro ao abrir o arquivo";
        return;
    }

    //recuperando o nome

    char auxiliar [256];
    entrada.read(reinterpret_cast <char*> (&auxiliar), sizeof (char)*256);
    this->nome ="";
    for (int i=0; i<256 && auxiliar[i] != '\0'; i++){
        this ->nome += auxiliar[i];
    }

    //recuperando o nivel
    entrada.read(reinterpret_cast <char*> (&this->nivel), sizeof(int));

    //recuperando a mochila

    int qtd;
    entrada.read(reinterpret_cast <char*> (&qtd), sizeof(int));

    mochila.clear();
    for (int i=0; i<qtd; i++){
        entrada.read(reinterpret_cast <char*> (&auxiliar), sizeof(char)*256);
        string desc = "";
        for (int j=0; j<256 && auxiliar[j]!='\0'; j++){
            desc += auxiliar[j];
        }
        float poder;
        entrada.read(reinterpret_cast <char*> (&poder), sizeof (float));
        mochila.push_back(Item(desc,poder));
    }
    //recuperando cabeca
    entrada.read(reinterpret_cast <char*> (&auxiliar), sizeof(char)*256);
    string desc2 = "";
    for (int j=0; j<256 && auxiliar[j]!='\0'; j++){
        desc2 += auxiliar[j];
    }

    float poder;
    entrada.read(reinterpret_cast <char*> (&poder), sizeof (float));

    this->cabeca = Item (desc2,poder);


    entrada.close();
}


int Personagem::qtdItens(){
    return mochila.size();
}
