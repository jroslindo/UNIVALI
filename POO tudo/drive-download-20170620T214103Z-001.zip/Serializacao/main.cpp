#include <iostream>

using namespace std;
#include "personagem.h"
#include "item.h"

int main()
{
   Personagem p1;
/*
   p1.setNome("joao");
   p1.setNivel(30);
   p1.adicionarItem(Item("espada", 100));
   p1.adicionarItem(Item("pacato", 1000));
   p1.adicionarItem(Item("gel para cabelo", 1));
   p1.setCabeca(Item("Helmo", 50));
   p1.salvar();*/


   Personagem p2;
   p2.carregar("joao");

   cout << "\nNome: " << p2.getNome();
   cout << "\nNIvel: " << p2.getNivel();
   cout << "\nCabeca: " << p2.getCabeca().getDescricao() << " Poder: " <<p2.getCabeca().getPoder();

   for(int i=0; i<p2.qtdItens();i++){
       cout << "\n - "<<p2.getItem(i).getDescricao() << " ( "<<p2.getItem(i).getPoder() << ")";
   }

   cout << "\n";
}
