#include <iostream>
#include <unordered_set>
#include <unordered_map>
using namespace std;
#include "carro.h"
int main()
{

    // unordered map

    Carro x,y;

    x.setCor("preto");
    x.setMarca("sla");
    x.setModelo("sla2");
    x.setPlaca("MKJ-5555");

    y.setCor("branco");
    y.setMarca("sla3");
    y.setModelo("sla4");
    y.setPlaca("MKJ-66");

    unordered_map <string,Carro> mcarros;

    mcarros[x.getPlaca()]=x;
    mcarros[y.getPlaca()]=y;

    /*for (pair <string, Carro> k: mcarros){
        cout << "\n" << k.first << " - " << k.second.getModelo();
    }
    cout << endl;*/

    cout << "\n" << mcarros [x.getPlaca()].getCor();

























    return 0; // teste com unordered_set
    Carro a,b;
    a.setCor("preto");
    a.setMarca("sla");
    a.setModelo("sla2");
    a.setPlaca("MKJ-5555");

    b.setCor("branco");
    b.setMarca("sla3");
    b.setModelo("sla4");
    b.setPlaca("MKJ-66");


    unordered_set <Carro> carros;

    carros.insert(a);
    carros.insert(b);

    unordered_set <Carro> :: iterator it;

    Carro busca;
    busca.setPlaca("MKJ-5555");
    carros.erase(busca); // removendo
    it = carros.find(busca);
    if(it != carros.end()){
        cout << "\nEncontrou: " << it->getPlaca();
    }else {
        cout << "deu merda";
    }
    cout << endl;

    /*for (Carro c: carros){
        cout << "\nPlaca: " << c.getPlaca();
    }
    cout << endl;*/


}

