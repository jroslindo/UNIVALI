#include <iostream>
#include <list>
#include <vector>
#include <set>
using namespace std;


#include "pessoa.h"
int main()
{

    Pessoa e,f;

    e.setNome("James People");
    e.setCpf("000.000.000-11");

    f.setNome("George Oliver");
    f.setCpf("111.111.111-00");

    set <Pessoa> spessoas;


    spessoas.insert(e);
    spessoas.insert(f);

    /*for (Pessoa p: spessoas){
        cout << "Nomes: " << p.getNome() << endl;
    }*/

    Pessoa busca;
    busca.setCpf("000.000.000-11");

    set <Pessoa> :: iterator it;
    it = spessoas.find(busca);
    if(it != spessoas.end()){
        cout << "\nEncontrou! Nome: " << it->getNome() << endl;
    }else{
        cout << "Nao encontrou!";
    }

    spessoas.erase(busca);











    return 0;//teste com o vectornn///////////////////////////////////////////////////
    Pessoa x, y;
    x.setNome("James People");
    x.setCpf("000.000.000-11");

    y.setCpf("111.111.111-00");
    y.setNome("George Oliver");

    vector <Pessoa> vpessoas;

    vpessoas.push_back(x);
    vpessoas.push_back(y);



    for(int i=0; i < vpessoas.size(); i++){
        cout << "Nomes: " << vpessoas[i].getNome() << endl;
    }


    return 0;  //teste com o list/////////////////////////////////////////////////////////////
    list <Pessoa> pessoas;

    Pessoa a;

    a.setNome("James People");
    a.setCpf("111.111.111-00");

    Pessoa b;

    b.setNome("George Oliver");
    b.setCpf("000.000.000.-11");
    //list <Pessoa> :: iterator it;

   // it=pessoas.begin();
  //  pessoas.insert(it,a);
    //pessoas.insert(it,b);
    pessoas.push_back(a);
    pessoas.push_back(b);

    pessoas.pop_front();

   // it=pessoas.begin();

    for (Pessoa x: pessoas){ // mesmo q o imprimir a baixo, so abstraimos o it++; (n mt util)
        cout << "Nome: " << x.getNome()<<endl;
    }

   /* while (it != pessoas.end()){

        cout << "Nome: " << it->getNome() << endl;
        it++;
    }*/

    //-----------------------------------------------------------------------------


    return 0;
}

