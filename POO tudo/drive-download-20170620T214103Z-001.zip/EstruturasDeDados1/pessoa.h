#ifndef PESSOA_H
#define PESSOA_H
#include <iostream>
using namespace std;

class Pessoa
{
private:
    string cpf;
    string nome;
public:
    Pessoa();
    Pessoa(string cpf);

    friend bool operator < (const Pessoa &esq, const Pessoa &dir);

    string getCpf() const;
    void setCpf(const string &value);
    string getNome() const;
    void setNome(const string &value);
};

#endif // PESSOA_H
