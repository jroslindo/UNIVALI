#ifndef MAGO_H
#define MAGO_H

#include "personagem.h"

class Mago: public Personagem
{
private:
    int mana;
public:
    Mago(string nome, string jogador);
    void misseisMagicos(Personagem &p);
    void bolaDeFogo(Personagem &p);
    void chuvaDeMeteoros(Personagem p1, Personagem p2);
    void curar(Personagem &p);
    void ressucitar(Personagem &p);
    int getMana() const;
    void setMana(int value);

    void imprimirMago();
};

#endif // MAGO_H
