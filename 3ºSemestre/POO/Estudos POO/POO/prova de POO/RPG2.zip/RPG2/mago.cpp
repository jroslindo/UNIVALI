#include "mago.h"


int Mago::getMana() const
{
    return mana;
}

void Mago::setMana(int value)
{
    mana = value;
}

void Mago::imprimirMago()
{
    imprimir();
    cout<<"\nMana:\t"<<mana;
    cout<<"\n----------------------------";
}
Mago::Mago(string nome, string jogador)
    :Personagem(nome, jogador)

{
    setInteligencia(20);
    mana = 100;
}

void Mago::misseisMagicos(Personagem &p){
    if (mana >= 5){
        p.levarDano(getInteligencia()+5);
        mana -= 5;
    }else{
        cout<<"\nMana insuficiente";
    }

}

void Mago::bolaDeFogo(Personagem &p){
    if (mana >= 50){
        p.levarDano(getInteligencia()+55);
        mana -= 50;
    }else{
        cout<<"\nMana insuficiente";
    }
}

void Mago::chuvaDeMeteoros(Personagem p1, Personagem p2){
    if (mana >= 20){

        p1.levarDano(getInteligencia()+12);
        p2.levarDano(getInteligencia()+12);

        mana -= 20;
    }else{
        cout<<"\nMana insuficiente";
    }
}

void Mago::curar(Personagem &p){
    if (mana >= 10){
        p.setVida(p.getVida()+10);
        mana -= 10;
    }else{
        cout<<"\nMana insuficiente";
    }
}

void Mago::ressucitar(Personagem &p){
    if (mana >= 80){
        if (p.morreu()){
            p.setVida(80);
            mana -= 80;
        }else{
            cout<<"\nNao se pode ressucitar alguem que esta vivo!";
        }
    }else{
        cout<<"\nMana insuficiente";
    }
}

