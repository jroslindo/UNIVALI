#include <iostream>

using namespace std;

#include "personagem.h"
#include "guerreiro.h"
#include "mago.h"

int main()
{
    Personagem p1("Joao", "Joaquim Silva");
    Guerreiro p2("Pedro", "Jose Rocha");
    Mago p3("Patricia", "Joana Fontes");
    p1.setForca(10);
    //p2.setForca(15);
    p1.setInteligencia(15);
    p2.setInteligencia(10);

    p2.setNomeArma("Machado Vorpal");
    p2.setDanoArma(50);

    p3.bolaDeFogo(p1);

    p3.chuvaDeMeteoros(p1, p2);
    p3.chuvaDeMeteoros(p1, p2);

    p3.ressucitar(p1);


    p1.imprimir();
    p2.imprimirGuerreiro();
    p3.imprimirMago();




    return 0;
}

