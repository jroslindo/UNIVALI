#ifndef _SUM_H_
#define _SUM_H_

long int sum(long int *v, long int n);

#endif
