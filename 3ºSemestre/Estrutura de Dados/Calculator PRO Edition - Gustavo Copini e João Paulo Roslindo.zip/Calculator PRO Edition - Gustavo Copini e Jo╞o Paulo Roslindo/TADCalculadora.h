/// /////////////////////////////////////////////////////// ///
/// UNIVERSIDADE DO VALE DO ITAJA� - UNIVALI                ///
/// CURSO DE ENGENHARIA DE COMPUTA��O - ESTRUTURA DE DADOS  ///
/// PROFESSOR: RAFAEL BALLOTTIN MARTINS                     ///
/// ALUNOS: GUSTAVO COPINI DECOL E JO�O PAULO ROSLINDO      ///
/// /////////////////////////////////////////////////////// ///
#ifndef TADCALCULADORA_H_INCLUDED
#define TADCALCULADORA_H_INCLUDED
/// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ///
/// /////////////////////////////////////////////////////////////////////////////////// STRUCTS /////////////////////////////////////////////////////////////////////////////////////////////////// ///
/// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ///

struct TNo {
    int x, y, conta_float;
    char dado;
    float valor;
    TNo * direita;
    TNo * esquerda;
    int tipo;       /// se for 0 � numero, se for 1 � operador

};

struct  TArvore {

    TNo * raiz;

};

struct TElemento {

    TNo * endereco;
    TElemento  * proximo;

};

struct TPilha {

    TElemento  *inicio;

};

struct TElemento_lista{

    TNo * endereco;
    TElemento_lista * proximo;

};

struct TLista{

    TElemento_lista *inicio;
    int tamanho_lista;

};
/// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ///
/// ////////////////////////////////////////////////////////////////////////////////////// LISTA ////////////////////////////////////////////////////////////////////////////////////////////////// ///
/// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ///

void inicializar_lista(TLista &lista){

    lista.inicio = NULL;
    lista.tamanho_lista = 0;
}

int contaLista(TLista &lista){

    int qtt=0;

    TElemento_lista *nav = lista.inicio;

    if(lista.inicio==NULL){
        cout<< "Lista Vazia!!!"<< endl;
    }else{
        while(nav!=NULL){
            nav = nav->proximo;
            qtt++;
        }
        return qtt;
    }

}

bool removeInicio_Lista(TLista &lista){

    if(lista.inicio==NULL){
        return false;
    }else{
        TElemento_lista *removedor = lista.inicio;
        lista.inicio = removedor->proximo;
        delete removedor;
        return true;
    }

}

TElemento_lista *novo_elemento_lista(TNo *dado){

    TElemento_lista *novo = new TElemento_lista;

    novo->endereco = dado;
    novo->proximo = NULL;

    return novo;

}

bool insere_Inicio_lista (TLista  &lista, TNo *dado){
    lista.tamanho_lista++;
    TElemento_lista * novo = novo_elemento_lista(dado);

    if(lista.inicio==NULL){
        lista.inicio = novo;
        return true;
    }else{

        novo -> proximo = lista.inicio;
        lista.inicio = novo;
        return true;
    }
}

bool removeFinal_Lista(TLista &lista){

    TElemento_lista *nav = lista.inicio;
    TElemento_lista *ultimo;
    if(lista.inicio==NULL){
        return false;
    }else{
        while(nav->proximo!=NULL){
            ultimo = nav;
            nav = nav->proximo;
        }
        ultimo->proximo = NULL;
        delete ultimo;
        return true;
    }

}

bool removePosicao_lista(TLista &lista,  TElemento_lista *chave){

    lista.tamanho_lista--;

    TElemento_lista *nav = lista.inicio;

    if (nav == chave){
        removeInicio_Lista(lista);
    }else{
        while (nav->proximo != chave){
            nav=nav->proximo;
        }
        nav->proximo = chave->proximo;

        //delete chave;
    }

}

bool imprime_lista (TLista  &lista){

        TElemento_lista *nav = lista.inicio;
        if(lista.inicio==NULL){
            return false;
        }else{
            while (nav != NULL){
                cout << "Nome tipo: " << nav->endereco->tipo << "  Valor: "<< nav->endereco->valor << endl;
                nav = nav ->proximo;
            }
        }
}


/// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ///
/// ////////////////////////////////////////////////////////////////////////////////////// PILHA ////////////////////////////////////////////////////////////////////////////////////////////////// ///
/// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ///


void inicializar_pilha (TPilha  &pilha){

    pilha.inicio=NULL;

}

TElemento *novo_elemento_dado(TNo *dado){

    TElemento *novo= new TElemento;
    novo->endereco = dado;
    novo->proximo = NULL;

    return novo;

}

void insereInicio (TPilha  &pilha, TNo *dadoInserir){

    TElemento *novo=novo_elemento_dado(dadoInserir);
    if (pilha.inicio == NULL){
        pilha.inicio = novo;
    }
    else{
        novo->proximo = pilha.inicio;
        pilha.inicio = novo;
    }

}

void remove_inicio (TPilha &pilha){

    TElemento *apagar = pilha.inicio;
    pilha.inicio = pilha.inicio->proximo;
    delete apagar;

}

void imprime_pilha(TPilha &pilha){
    TElemento *nav = pilha.inicio;
    while (nav!=NULL){
        cout << pilha.inicio->endereco << endl;
        nav=nav->proximo;
    }
}


/// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ///
/// /////////////////////////////////////////////////////////////////////////////////// ARVORE //////////////////////////////////////////////////////////////////////////////////////////////////// ///
/// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ///

void inicializar_arvore(TArvore &no){

    no.raiz = NULL;

}

TNo *encapsula (){///funcao mt util, para encapsular, facilitou muito

    TNo *novo = new TNo;
    novo->dado ='#';
    novo->direita =NULL;
    novo->esquerda =NULL;
    novo->tipo = 2;
    novo->valor = -56165165;
    novo->conta_float=0;
    novo->x=0;
    novo->y=0;

    return novo;
}

TNo *inserir_arvore_parentes_aberto (TNo *&no, TPilha &pilha){ ///funcao mt importante

    if(no == NULL){ ///se a arvore estiver zerada
        TNo *novo = encapsula();
        novo->esquerda= encapsula(); /// criamos um a esquerda ja
        no = novo; /// definimos um no base, com x e y prontos;
        no->x=640;
        no->y=30;
        insereInicio(pilha, no);
        no->esquerda->x = no->x - 200; /// a esquerda ja define um pouco mais longe
        no->esquerda->y = no->y +40;
        return no->esquerda; /// importante sempre retornar o esquerda do no, pois o apontador vai recebe-lo
    }else{
        TNo *novoe = encapsula(); /// se n for o inicial
        no->esquerda = novoe;
        no->esquerda->x = no->x - 60; //
        no->esquerda->y = no->y +40; //
        insereInicio(pilha, no);
        return no->esquerda;
    }
}

TNo *inserir_arvore_operador (TPilha pilha, char operador, TNo *&raiz){

    TNo *modifica = pilha.inicio->endereco; /// pega o endere�o da pilha
    modifica->tipo = 1; /// ele vira tipo 1
    modifica->dado = operador; /// recebe o operador

    modifica->direita = encapsula(); /// crio a direita

    if(modifica == raiz){ /// se for na raiz a direita fica bem longe para evitar colisoes
        modifica->direita->x = modifica->x + 200;
        modifica->direita->y = modifica->y + 40;

    }else{
        modifica->direita->x = modifica->x + 60; /// x,y
        modifica->direita->y = modifica->y + 40;
    }
    TNo *apontador = modifica->direita;

    return apontador; /// retorna o apontador, que � o direita

}

void inserir_arvore_algarismo (TNo *&no, char numero){

    float valor,i; /// converte para int

    if(numero == '0' )
        valor = 0;
    if(numero == '1' )
        valor = 1;
    if(numero == '2' )
        valor = 2;
    if(numero == '3' )
        valor = 3;
    if(numero == '4' )
        valor = 4;
    if(numero == '5' )
        valor = 5;
    if(numero == '6' )
        valor = 6;
    if(numero == '7' )
        valor = 7;
    if(numero == '8' )
        valor = 8;
    if(numero == '9' )
        valor = 9;

    if(no->valor == -56165165){ /// valor extremamente improvavel
        no->valor = valor;
        no->tipo = 0;
    }else{
        if(numero == '.'){ /// fiz isso caso o numero seja mais de uma casa ou com virgula '.'
            no->conta_float=1;
        }else{

            if(no->conta_float == 0){
                no->valor *=10;
                no->valor += valor;
                no->tipo = 0;
            }else if(no->conta_float >=1 ){
                for(i=0; i<no->conta_float; i++)
                    valor /= 10;
                no->conta_float++;
                no->valor += valor;
            }
        }
    }

}

void imprimirArvore(TNo *&no){ /// imprimir basico sem allegro

    if(no!=NULL){
        if(no->tipo==1)
            cout<<no->dado<<endl;
        if(no->tipo==0)
            cout<<no->valor<<endl;
        imprimirArvore(no->esquerda);
        imprimirArvore(no->direita);
    }
}

void monta_arvore (TNo *&no, TNo *&apontador,TPilha &pilha_de_expressao, string expressao){ /// while que vai ver a expressao e colocar char a char na arvore
int i=1; /// i come�a em 1 pois n preciso checar o primeiro valor
    apontador = inserir_arvore_parentes_aberto(no, pilha_de_expressao); /// mt importante o apontador, pois ele recebe o retorno
    while (expressao[i] != '\0'){
        if(expressao[i] == '('){
            apontador = inserir_arvore_parentes_aberto(apontador, pilha_de_expressao);
        }else if(expressao[i] == ')'){
            remove_inicio(pilha_de_expressao);
        }else if(expressao[i] == '+' || expressao[i] == '-' || expressao[i] == '*' || expressao[i] == '/'){
            apontador = inserir_arvore_operador(pilha_de_expressao,expressao[i],no);
        }else{
            inserir_arvore_algarismo(apontador, expressao[i]);
        }
        i++;
    }
}

void bota_na_lista (TNo *& no, TLista &lista){ /// percorre a arvore e poem na lista

    if(no!=NULL){
        insere_Inicio_lista(lista, no);
        bota_na_lista(no->esquerda,lista);
        bota_na_lista(no->direita,lista);
    }

}

void executa_arvore (TNo *&arvore_raiz, TLista &lista){ /// executa a arvore como no allegro, apenas sem as fun��es dele
    int i=0;
    bool sair =false;
    bota_na_lista (arvore_raiz, lista);

    TElemento_lista *nav_lista =lista.inicio;

    imprimirArvore (arvore_raiz);

    while(nav_lista->proximo->proximo != NULL && sair == false){

        if (nav_lista->endereco->tipo == 0 && nav_lista->proximo->endereco->tipo == 0 && nav_lista->proximo->proximo->endereco->tipo==1 ){

            if(nav_lista->proximo->proximo->endereco->dado == '+' && nav_lista->proximo->proximo->endereco->tipo == 1){
                nav_lista->proximo->proximo->endereco->valor =  nav_lista->endereco->valor + nav_lista->proximo->endereco->valor;
            }

            if(nav_lista->proximo->proximo->endereco->dado == '-'){
                nav_lista->proximo->proximo->endereco->valor =  nav_lista->proximo->endereco->valor - nav_lista->endereco->valor;
            }

            if(nav_lista->proximo->proximo->endereco->dado == '*'){
                nav_lista->proximo->proximo->endereco->valor =  nav_lista->endereco->valor * nav_lista->proximo->endereco->valor;
            }

            if(nav_lista->proximo->proximo->endereco->dado == '/'){
                nav_lista->proximo->proximo->endereco->valor =   nav_lista->proximo->endereco->valor / nav_lista->endereco->valor;
            }

            nav_lista->proximo->proximo->endereco->tipo = 0;

            nav_lista->proximo->proximo->endereco->direita = NULL;
            nav_lista->proximo->proximo->endereco->esquerda = NULL;

            if(lista.tamanho_lista >3){
                removePosicao_lista(lista, nav_lista->proximo);
                removePosicao_lista(lista, nav_lista);
            }else{
                sair=true;
            }
            i++;
            nav_lista=lista.inicio;

            }else{
                nav_lista=nav_lista->proximo;
                i++;
            }
    }

}

bool verifica_arvore_2(TNo *&no){

    if(no!=NULL){ /// verifica se n deu falha ao montar a arvore
        if(no->dado == '#' && no->tipo == 1){
            return true;
        }else{
            verifica_arvore_2(no->esquerda);
            verifica_arvore_2(no->direita);
        }
    }
}

int verifica_arvore_3(TNo *&no){

    if(no!=NULL) /// conta os termos da arvore
        return verifica_arvore_3(no->esquerda) + verifica_arvore_3(no->direita) + 1;

}

bool verifica_arvore(string expressao){

    bool teste2 = true, teste3=true; /// faz uma verifica��o simulando uma arvore
    int nteste3=0, i=0, contagem=0;
    TArvore arvore_teste;
    TPilha pilha_teste;
    TLista lista_teste;

    inicializar_arvore(arvore_teste);
    inicializar_lista(lista_teste);
    inicializar_pilha(pilha_teste);

    TNo *apontador_teste = arvore_teste.raiz;

/// monta arvore
    monta_arvore (arvore_teste.raiz, apontador_teste,pilha_teste, expressao);
    imprimirArvore(arvore_teste.raiz);

    teste2 = !verifica_arvore_2(arvore_teste.raiz);

    nteste3 = verifica_arvore_3(arvore_teste.raiz);

    for (i=0; expressao[i] != '\0'; i++){ /// a contagem da expressao tem q bater, caso contrario esta errada
        if(((expressao[i] >= 48 && expressao[i] <=57  ) && !(expressao[i+1] >= 48 && expressao[i+1] <=57 || expressao[i+1]=='.')) || expressao[i] == '+' || expressao[i] == '-' || expressao[i] == '*'|| expressao[i] == '/' )
            contagem ++;
    }

    if (nteste3 == contagem)
        teste3=true;
    else
        teste3=false;

    if(teste2 == true && teste3== true)
        return true;
    else
        return false;
}

bool verifica (string expressao){ /// verifica a expressao

    int parenteses_esquerda =0, parenteses_direita =0, i=0;

    /// 1� Regra, deve come�ar com o parenteses '('
    if (expressao[0] == '('){
        /// 2�Regra, numero de parenteses tem que ser iguais
        while (expressao[i] != '\0'){
            if(expressao[i] == '(')
               parenteses_esquerda++;
            if(expressao[i] == ')')
               parenteses_direita++;
            i++;
        }
        if (parenteses_direita != parenteses_esquerda)
            return false;
        /// 3� Regra, deve terminar com ')'
        if (expressao[i-1] != ')')
           return false;
        i=0;
        while (expressao[i] != '\0'){
            if (expressao[i] == '(' && expressao[i+1] == ')')
                return false;
            i++;
        }



        return true;
    }else{
        return false;
    }
}

string arruma_expressao (string &expressao){ /// arruma expressao
    bool retorna =false;
    int i=0, j=0;
    string original;
    while (expressao[i] != '\0'){
        j=i;
        if (expressao[i] == '(' && (expressao[i+1] == '+' || expressao[i+1] == '-') && (expressao[i+2] >= 48 && expressao[i+2] <= 57)){
            retorna=true;
            while(expressao[j] != '\0'){
                j++;
            }
            cout << "J: " << j;
            while (j>i){
                expressao[j+1]=expressao[j];
                j--;
            }
            expressao[i+1] = '0';
        }
        i++;
    }
    if(retorna == true)
        return expressao+')';
    else
        return expressao;
}

#endif // TADCALCULADORA_H_INCLUDED
