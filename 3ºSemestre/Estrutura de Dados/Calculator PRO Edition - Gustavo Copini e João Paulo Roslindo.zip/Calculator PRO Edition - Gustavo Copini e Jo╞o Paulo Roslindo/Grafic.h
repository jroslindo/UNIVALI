/// /////////////////////////////////////////////////////// ///
/// UNIVERSIDADE DO VALE DO ITAJA� - UNIVALI                ///
/// CURSO DE ENGENHARIA DE COMPUTA��O - ESTRUTURA DE DADOS  ///
/// PROFESSOR: RAFAEL BALLOTTIN MARTINS                     ///
/// ALUNOS: GUSTAVO COPINI DECOL E JO�O PAULO ROSLINDO      ///
/// /////////////////////////////////////////////////////// ///
#ifndef GRAFIC_H_INCLUDED
#define GRAFIC_H_INCLUDED

/// essa biblioteca possui as fun��es principais do allegro e algumas que eram da arvore e foram modificadas
/// o motivo de manter algumas fun��es nas duas bibliotecas e para teste de console, assim a arvore n funciona apenas no allegro

int menu (){
    int LARGURA_TELA = 640; /// largura altura
    int ALTURA_TELA =480;
    ///variaveis
    ALLEGRO_DISPLAY *janela = NULL;
    ALLEGRO_FONT *fonte = NULL;
    ALLEGRO_EVENT_QUEUE *fila_eventos = NULL;
    ALLEGRO_BITMAP *instrucoes = NULL, *calcular = NULL, *creditos=NULL, *sair_bit = NULL; /// variaveis do allegro

    /// Init
    al_init();
    al_init_font_addon();
    al_init_ttf_addon(); ///inicializando
    al_install_mouse();


    /// Escolha da fonte
    fonte = al_load_font("ALGER.TTF", 60, 0); /// fonte

    /// Janela
    janela = al_create_display(640, 480);
    al_clear_to_color(al_map_rgb(245,222,179));
    al_set_system_mouse_cursor(janela, ALLEGRO_SYSTEM_MOUSE_CURSOR_DEFAULT);
    /// Prints
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 320, 50, ALLEGRO_ALIGN_CENTER, "CALCULADORA");
    fonte = al_load_font("ALGER.TTF", 20, 0);
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 320, 150, ALLEGRO_ALIGN_CENTER, "CALCULAR");
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 320, 200, ALLEGRO_ALIGN_CENTER, "INSTRUCOES");  /// prints
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 320, 250, ALLEGRO_ALIGN_CENTER, "CREDITOS");
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 320, 300, ALLEGRO_ALIGN_CENTER, "SAIR");

    /// Mouse
    calcular = al_create_bitmap(110, 35);
    instrucoes = al_create_bitmap(140,35);
    creditos = al_create_bitmap (110,35);
    sair_bit = al_create_bitmap (70,35); ///criando bitmaps


    fila_eventos = al_create_event_queue(); /// fila de eventos e registrar mouse
    al_register_event_source(fila_eventos, al_get_mouse_event_source());


    int sair = 0;
    while (sair==0)
    {
        /// Verificamos se h� eventos na fila
        while (!al_is_event_queue_empty(fila_eventos))
        {
            ALLEGRO_EVENT evento;
            al_wait_for_event(fila_eventos, &evento);
            /// Ou se o evento foi um clique do mouse
            if (evento.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP) /// ao soltar o botao do mouse
            {
                ///if para o calcular
                if (evento.mouse.x >= 265 && evento.mouse.x <= 375 && evento.mouse.y <= 175 && evento.mouse.y >= 140) /// se for nessa area retorna 0 para o menu
                {
                    al_destroy_bitmap(sair_bit);
                    al_destroy_bitmap(calcular);
                    al_destroy_bitmap(creditos);
                    al_destroy_bitmap(instrucoes);
                    al_destroy_display(janela);
                    al_destroy_event_queue(fila_eventos);
                    return 0;
                }
                ///if para instrucoes
                if (evento.mouse.x >= 250 && evento.mouse.x <= 390 && evento.mouse.y <= 235 && evento.mouse.y >= 200) /// se for nessa area retorna 1 para o menu, e assim kd if
                {
                    al_destroy_bitmap(sair_bit);
                    al_destroy_bitmap(calcular);
                    al_destroy_bitmap(creditos);
                    al_destroy_bitmap(instrucoes);
                    al_destroy_display(janela);
                    al_destroy_event_queue(fila_eventos);
                    return 1;
                }
                ///if creditos
                if (evento.mouse.x >= 265 && evento.mouse.x <= 375 && evento.mouse.y <= 285 && evento.mouse.y >= 250)
                {
                    al_destroy_bitmap(sair_bit);
                    al_destroy_bitmap(calcular);
                    al_destroy_bitmap(creditos);
                    al_destroy_bitmap(instrucoes);
                    al_destroy_display(janela);
                    al_destroy_event_queue(fila_eventos);
                    return 2;
                }
                ///if sair
                if (evento.mouse.x >= 290 && evento.mouse.x <= 360 && evento.mouse.y <= 385 && evento.mouse.y >= 300)
                {
                    al_destroy_bitmap(sair_bit);
                    al_destroy_bitmap(calcular);
                    al_destroy_bitmap(creditos);
                    al_destroy_bitmap(instrucoes);
                    al_destroy_display(janela);
                    al_destroy_event_queue(fila_eventos);
                    return 3;
                }
            }

        }
        /// Atualiza a tela
        al_flip_display();
    }
}

string janela_de_entrada (){
    bool sair = false;
    string expressao, retorno;
    int LARGURA_TELA = 900;
    int ALTURA_TELA =100;
    int i=0,j=0,k;
    ///variaveis
    ALLEGRO_DISPLAY *janela = NULL;
    ALLEGRO_FONT *fonte = NULL;
    ALLEGRO_EVENT_QUEUE *fila_eventos = NULL;

    /// Init
    al_init();
    al_init_font_addon();
    al_init_ttf_addon();
    al_install_keyboard();

    /// Escolha da fonte
    fonte = al_load_font("ALGER.TTF", 25, 0);

    /// Janela
    janela = al_create_display(LARGURA_TELA, ALTURA_TELA);
    al_clear_to_color(al_map_rgb(245,222,179));

    /// Fonte
    al_draw_text(fonte, al_map_rgb(0,0,0), 10, 30, ALLEGRO_ALIGN_LEFT, "Expressao: ");

    al_flip_display();
    /// Teclado
    fila_eventos = al_create_event_queue();
    al_register_event_source(fila_eventos, al_get_display_event_source(janela));
    al_register_event_source(fila_eventos, al_get_keyboard_event_source());


    while (!sair)
    {
        while(!al_is_event_queue_empty(fila_eventos))
        {
            ALLEGRO_EVENT evento;
            al_wait_for_event(fila_eventos, &evento);

            if (evento.type == ALLEGRO_EVENT_KEY_DOWN)                  /// tratamos o expressao como um vetor armazenamento e modifica, e usamos o retorno para a expressao final
            {
                switch(evento.keyboard.keycode)
                {
                case ALLEGRO_KEY_PAD_0:  /// i � a posi��o do vet a ser inserida
                    expressao[i]= '0';
                    i++;
                break;
                case ALLEGRO_KEY_PAD_1:
                    expressao[i]= '1';
                    i++;
                break;
                case ALLEGRO_KEY_PAD_2:
                    expressao[i]= '2';
                    i++;
                break;
                case ALLEGRO_KEY_PAD_3:
                    expressao[i]= '3';
                    i++;
                break;
                case ALLEGRO_KEY_PAD_4:
                    expressao[i]= '4';
                    i++;
                break;
                case ALLEGRO_KEY_PAD_5:
                    expressao[i]= '5';
                    i++;
                break;
                case ALLEGRO_KEY_PAD_6:
                    expressao[i]= '6';
                    i++;
                break;
                case ALLEGRO_KEY_PAD_7:
                    expressao[i]= '7';
                    i++;
                break;
                case ALLEGRO_KEY_PAD_8:
                    expressao[i]= '8';
                    i++;
                break;
                case ALLEGRO_KEY_PAD_9:
                    expressao[i]= '9';
                    i++;
                break;
                case ALLEGRO_KEY_PAD_ASTERISK:
                    expressao[i]= '*';
                    i++;
                break;
                case ALLEGRO_KEY_PAD_PLUS:
                    expressao[i]= '+';
                    i++;
                break;
                case ALLEGRO_KEY_PAD_MINUS:
                    expressao[i]= '-';
                    i++;
                break;
                case ALLEGRO_KEY_PAD_SLASH:
                    expressao[i]= '/';
                    i++;
                break;
                case ALLEGRO_KEY_9:
                    expressao[i]='(';
                    i++;
                break;
                case ALLEGRO_KEY_0:
                    expressao[i]=')';
                    i++;
                break;
                case ALLEGRO_KEY_BACKSPACE:
                    for (i=0; expressao[i] != '\0'; i++){}  /// garante o ultimo i
                    expressao[i-1]='\0';  /// coloca nulo na ultima posi
                    i--; /// subtrai posi
                break;
                case ALLEGRO_KEY_FULLSTOP:
                    expressao[i]='.';
                    i++;
                break;
                case ALLEGRO_KEY_PAD_ENTER: /// concatena retornando com a expressao e retorna
                    for (j=0; j<i; j++){
                        retorno+=expressao[j];
                    }
                    cout << "Expressao: " << retorno << endl;
                    al_destroy_display(janela);
                    al_destroy_event_queue(fila_eventos);
                    return retorno;
                break;
                case ALLEGRO_KEY_ENTER: /// mesma coisa se for o outro enter
                    for (j=0; j<i; j++){
                        retorno+=expressao[j];
                    }
                    cout << "Expressao: " << retorno << endl;
                    al_destroy_display(janela);
                    al_destroy_event_queue(fila_eventos);
                    return retorno;
                break;

                }
            }
                al_clear_to_color(al_map_rgb(245,222,179));
                al_draw_text(fonte, al_map_rgb(0, 0, 0), 10, 30, ALLEGRO_ALIGN_LEFT, "Expressao: "); /// prints

                for (j=0; j<i; j++){
                    al_draw_textf(fonte, al_map_rgb(0, 0, 0), 175+15*j, 30, ALLEGRO_ALIGN_LEFT, "%c",expressao[j]); /// print letra a letra de uma variavel
                }

                al_flip_display();

        }
    }

}

void errado(){

    /// Variaveis
    int LARGURA_TELA = 900;
    int ALTURA_TELA =100;
    ALLEGRO_DISPLAY *janela = NULL;
    ALLEGRO_FONT *fonte = NULL;

    /// Init
    al_init();
    al_init_font_addon();
    al_init_ttf_addon();

    /// Escolha da fonte
    fonte = al_load_font("ALGER.TTF", 25, 0);

    /// Janela
    janela = al_create_display(LARGURA_TELA, ALTURA_TELA);
    al_clear_to_color(al_map_rgb(245,222,179));

    /// Fonte
    al_draw_text(fonte, al_map_rgb(255, 0, 0), 10, 30, ALLEGRO_ALIGN_LEFT, "Expressao invalida, espere 5 segundos!!! ");

    al_flip_display();
    al_rest(5);
    al_destroy_display(janela);
}

void imprime_allegro(TNo *&no){

    if(no!=NULL){
            ALLEGRO_FONT *fonte = NULL;
            al_init_font_addon();
            al_init_ttf_addon();
            fonte = al_load_font("ALGER.TTF", 20, 0); ///imprime em x e y se for numero ou sinal
        if(no->tipo==1)
                al_draw_textf(fonte, al_map_rgb(0, 0, 0), no->x, no->y, ALLEGRO_ALIGN_CENTRE, "%c", no->dado);
        if(no->tipo==0)
                al_draw_textf(fonte, al_map_rgb(0, 0, 0), no->x, no->y, ALLEGRO_ALIGN_CENTRE, "%.2f", no->valor);
        imprime_allegro(no->esquerda);
        imprime_allegro(no->direita);///caminha
    }

}

void executa_arvore_allegro (TNo *&arvore_raiz, TLista &lista, ALLEGRO_DISPLAY *janela, string expressao){

    ALLEGRO_FONT *fonte = NULL;
    ALLEGRO_EVENT_QUEUE *fila_eventos = NULL;  /// var allegro

    al_init_font_addon();
    al_init_ttf_addon(); ///inits + fonte
    fonte = al_load_font("ALGER.TTF", 25, 0);

    al_install_keyboard(); /// keyboard

    fila_eventos = al_create_event_queue();
    al_register_event_source(fila_eventos, al_get_display_event_source(janela));
    al_register_event_source(fila_eventos, al_get_keyboard_event_source());


    al_clear_to_color(al_map_rgb(245,222,179));


    int i=0;
    bool sair =false, sair_allegro=false;
    bota_na_lista (arvore_raiz, lista);

    TElemento_lista *nav_lista =lista.inicio; /// navegador

    while(nav_lista->proximo->proximo != NULL && sair == false){ /// verifica��o para acabar no anti penultimo

        if (nav_lista->endereco->tipo == 0 && nav_lista->proximo->endereco->tipo == 0 && nav_lista->proximo->proximo->endereco->tipo==1 ){ /// se atender numero - numero e sinal faz

            if(nav_lista->proximo->proximo->endereco->dado == '+' && nav_lista->proximo->proximo->endereco->tipo == 1){
                nav_lista->proximo->proximo->endereco->valor =  nav_lista->endereco->valor + nav_lista->proximo->endereco->valor;
            }

            if(nav_lista->proximo->proximo->endereco->dado == '-'){
                nav_lista->proximo->proximo->endereco->valor =  nav_lista->proximo->endereco->valor - nav_lista->endereco->valor;
            }

            if(nav_lista->proximo->proximo->endereco->dado == '*'){
                nav_lista->proximo->proximo->endereco->valor =  nav_lista->endereco->valor * nav_lista->proximo->endereco->valor;
            }

            if(nav_lista->proximo->proximo->endereco->dado == '/'){
                nav_lista->proximo->proximo->endereco->valor =   nav_lista->proximo->endereco->valor / nav_lista->endereco->valor;
            }

            nav_lista->proximo->proximo->endereco->tipo = 0; /// define o tipo do antigo sinal para o numero

            nav_lista->proximo->proximo->endereco->direita = NULL; /// mata os filhos
            nav_lista->proximo->proximo->endereco->esquerda = NULL;

            if(lista.tamanho_lista >3){ /// enquanto o tamanho da lista for maior q 3
                removePosicao_lista(lista, nav_lista->proximo); /// remove os calculados da lista
                removePosicao_lista(lista, nav_lista);
            }else{ /// se n for maior q 3, ja esta no final do while pois a lista esta acabando
                sair=true;
            }
            i++; /// soma i
            nav_lista=lista.inicio; /// nav_lista recome�a do inicio

            al_clear_to_color(al_map_rgb(245,222,179)); /// cor da tela
            al_draw_text(fonte, al_map_rgb(255, 0, 0), 60, 670, ALLEGRO_ALIGN_LEFT, "Expressao: ");
            al_draw_text(fonte, al_map_rgb(255, 0, 0), 850, 670, ALLEGRO_ALIGN_LEFT, "Resultado: "); /// prints

            for (int i=0; expressao[i] != '\0'; i++)
            al_draw_textf(fonte, al_map_rgb(0, 0, 0), 220+i*15, 670, ALLEGRO_ALIGN_LEFT, "%c", expressao[i]); /// print da expressao

            imprime_allegro(arvore_raiz); /// print da arvore

            sair_allegro=false; /// a espera do enter para continuar a execu��o da arvore, normal como qualquer intera��o com o teclado
            while (sair_allegro==false)
            {
                while(!al_is_event_queue_empty(fila_eventos))
                {
                    ALLEGRO_EVENT evento;
                    al_wait_for_event(fila_eventos, &evento);

                    if (evento.type == ALLEGRO_EVENT_KEY_DOWN)
                    {
                        switch(evento.keyboard.keycode)
                        {
                            case ALLEGRO_KEY_ENTER:
                                sair_allegro = true;
                            break;
                            case ALLEGRO_KEY_PAD_ENTER:
                                sair_allegro = true;
                            break;
                        }
                    }
                }
            }
            al_flip_display();
        }else{
            nav_lista=nav_lista->proximo;
            i++;
        }
    }
}

void executar_allegro (string expressao){
    /// Coisas da arvore
    TArvore arvore_de_expressao;  /// essencial para o funcionamento da arvore
    TPilha pilha_de_expressao; /// usado na constru��o da arvore
    TLista lista_de_expressao; /// usado na execu��o da arvore
    inicializar_arvore(arvore_de_expressao); /// inicializar
    inicializar_pilha(pilha_de_expressao);
    inicializar_lista(lista_de_expressao);
    TNo *apontador = arvore_de_expressao.raiz; /// muito importante, aponta onde sera inserido o novo n�

    monta_arvore (arvore_de_expressao.raiz, apontador,pilha_de_expressao, expressao); /// fun��o q monta a arvore

    /// Variaveis
    int LARGURA_TELA = 1280; /// allegro
    int ALTURA_TELA =720;
    ALLEGRO_DISPLAY *janela = NULL;
    ALLEGRO_FONT *fonte = NULL;

    /// Init
    al_init();
    al_init_font_addon();
    al_init_ttf_addon();

    /// Escolha da fonte
    fonte = al_load_font("ALGER.TTF", 25, 0);


    /// Janela
    janela = al_create_display(LARGURA_TELA, ALTURA_TELA);
    al_clear_to_color(al_map_rgb(245,222,179));

    /// Fonte
    al_draw_text(fonte, al_map_rgb(255, 0, 0), 60, 670, ALLEGRO_ALIGN_LEFT, "Expressao: ");
    al_draw_text(fonte, al_map_rgb(255, 0, 0), 850, 670, ALLEGRO_ALIGN_LEFT, "Resultado: ");
    for (int i=0; expressao[i] != '\0'; i++)
    al_draw_textf(fonte, al_map_rgb(0, 0, 0), 220+i*15, 670, ALLEGRO_ALIGN_LEFT, "%c", expressao[i]);
    imprime_allegro(arvore_de_expressao.raiz);
    al_flip_display();

    executa_arvore_allegro(arvore_de_expressao.raiz,lista_de_expressao,janela,expressao); /// executa a arvore
    cout << "PRONTO";

    fonte = al_load_font("ALGER.TTF", 25, 0);
    al_draw_textf(fonte, al_map_rgb(0, 0, 0), 1000, 670, ALLEGRO_ALIGN_LEFT, "%.2f", arvore_de_expressao.raiz->valor);
    for (int i=0; expressao[i] != '\0'; i++)
    al_draw_textf(fonte, al_map_rgb(0, 0, 0), 220+i*15, 670, ALLEGRO_ALIGN_LEFT, "%c", expressao[i]);

    fonte = al_load_font("ALGER.TTF", 60, 0);
    al_draw_textf(fonte, al_map_rgb(0, 0, 0), 640, 300, ALLEGRO_ALIGN_CENTER, "PRONTO!!!");


    al_flip_display();
    al_rest(5);
    al_destroy_display(janela);

}

void instrucoes(){

    int LARGURA_TELA = 640;  //variaveis para largura de tela e altura, necessarias para n ter q decorar o valor
    int ALTURA_TELA =480;
    ///variaveis
    ALLEGRO_DISPLAY *janela = NULL;   //variaveis do allegro
    ALLEGRO_FONT *fonte = NULL;
    ALLEGRO_EVENT_QUEUE *fila_eventos = NULL;

    /// Init
    al_init();
    al_init_font_addon();  //iniciando o allegro
    al_init_ttf_addon();
    al_install_mouse();


    /// Escolha da fonte
    fonte = al_load_font("ALGER.TTF", 60, 0);  //load da nossa fonte

    /// Janela
    janela = al_create_display(640, 480); // criando display do tamanho
    al_clear_to_color(al_map_rgb(245,222,179)); // colocando cor
    /// Prints
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 320, 50, ALLEGRO_ALIGN_CENTER, "INSTRUCOES");
    fonte = al_load_font("ALGER.TTF", 15, 0);
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 10, 150, ALLEGRO_ALIGN_LEFT, "Bem vindo(a), a nossa calculadora de expressoes matematicas!!!");
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 10, 170, ALLEGRO_ALIGN_LEFT, "Digite uma expressao valida, para que a arvore seja montada e resolvida!");
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 10, 190, ALLEGRO_ALIGN_LEFT, "Apos inserir a expressao, va pressionando enter para ver passo a passo!");
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 10, 210, ALLEGRO_ALIGN_LEFT, "Lembre-se, voce deve inserir a expressao na forma correta algebricamente!");
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 10, 230, ALLEGRO_ALIGN_LEFT, "Caso desejar inserir numeros com virgula, utilize o . Ex: 2.5 , 22.5!!");
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 10, 250, ALLEGRO_ALIGN_LEFT, "EXEMPLOS: (5+2) || ((5+2)*2) || ((5+2)/(5+2)) || (((5+2)*(5+2))/(5-2)) || ....");
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 10, 270, ALLEGRO_ALIGN_LEFT, "((5+2)*(-1)) || ((((5+2)*7.5)/10)*1000)|| ....");
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 10, 300, ALLEGRO_ALIGN_LEFT, "SEMPRE INSIRA PARENTESES PARA DEFINIR AS PRIORIDADES !!!");
    fonte = al_load_font("ALGER.TTF", 30, 0);
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 320, 350, ALLEGRO_ALIGN_CENTER, "DIVIRTA-SE !!!");
    fonte = al_load_font("ALGER.TTF", 10, 0);
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 10, 450, ALLEGRO_ALIGN_LEFT, "PRESSIONE ENTER PARA VOLTAR AO MENU PRINCIPAL");

    al_install_keyboard(); //instalar keyboard

    fila_eventos = al_create_event_queue();  // nossa fila de eventos
    al_register_event_source(fila_eventos, al_get_display_event_source(janela)); //registrar os eventos na fila para usar o teclado
    al_register_event_source(fila_eventos, al_get_keyboard_event_source());

    al_flip_display(); //atualizar tela
    bool sair_allegro=false;
            while (sair_allegro==false)
            {
                while(!al_is_event_queue_empty(fila_eventos)) //enquanto a fila estiver vazia
                {
                    ALLEGRO_EVENT evento; //criando um unico evento
                    al_wait_for_event(fila_eventos, &evento);  //esperar por evento e gravar na fila de eventos

                    if (evento.type == ALLEGRO_EVENT_KEY_DOWN) //quando apertar
                    {
                        switch(evento.keyboard.keycode) // switch pelo codigo da tecla
                        {
                            case ALLEGRO_KEY_ENTER:
                                al_destroy_display(janela); //destruir janela
                                sair_allegro = true; // sair do allegro e voltar para o while do main
                            break;
                            case ALLEGRO_KEY_PAD_ENTER:
                                al_destroy_display(janela);
                                sair_allegro = true;
                            break;
                        }
                    }
                }
            }
}

void creditos(){

    int LARGURA_TELA = 640;/// ////////////////////foi usado reaproveitamento de codigo do instru��es para os creditos////////////////////////////////////////////////////
    int ALTURA_TELA =480;
    ///variaveis
    ALLEGRO_DISPLAY *janela = NULL;
    ALLEGRO_FONT *fonte = NULL;
    ALLEGRO_EVENT_QUEUE *fila_eventos = NULL;

    /// Init
    al_init();
    al_init_font_addon();
    al_init_ttf_addon();
    al_install_mouse();


    /// Escolha da fonte
    fonte = al_load_font("ALGER.TTF", 60, 0);

    /// Janela
    janela = al_create_display(640, 480);
    al_clear_to_color(al_map_rgb(245,222,179));

    /// Prints
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 320, 50, ALLEGRO_ALIGN_CENTER, "CREDITOS");
    fonte = al_load_font("ALGER.TTF", 20, 0);
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 10, 150, ALLEGRO_ALIGN_LEFT, "UNIVERSIDADE DO VALE DO ITAJAI - UNIVALI");
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 10, 200, ALLEGRO_ALIGN_LEFT, "CURSO DE ENGENHARIA DE COMPUTACAO - ESTRUTURA DE DADOS");
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 10, 250, ALLEGRO_ALIGN_LEFT, "PROFESSOR: RAFAEL BALLOTTIN MARTINS");
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 10, 300, ALLEGRO_ALIGN_LEFT, "ALUNOS: GUSTAVO COPINI DECOL - JOAO PAULO ROSLINDO");
    fonte = al_load_font("ALGER.TTF", 10, 0);
    al_draw_text(fonte, al_map_rgb(0, 0, 0), 10, 450, ALLEGRO_ALIGN_LEFT, "PRESSIONE ENTER PARA VOLTAR AO MENU PRINCIPAL");


    al_install_keyboard();

    fila_eventos = al_create_event_queue();
    al_register_event_source(fila_eventos, al_get_display_event_source(janela));
    al_register_event_source(fila_eventos, al_get_keyboard_event_source());

    al_flip_display();
    bool sair_allegro=false;
            while (sair_allegro==false)
            {
                while(!al_is_event_queue_empty(fila_eventos))
                {
                    ALLEGRO_EVENT evento;
                    al_wait_for_event(fila_eventos, &evento);

                    if (evento.type == ALLEGRO_EVENT_KEY_DOWN)
                    {
                        switch(evento.keyboard.keycode)
                        {
                            case ALLEGRO_KEY_ENTER:
                                al_destroy_display(janela);
                                sair_allegro = true;
                            break;
                            case ALLEGRO_KEY_PAD_ENTER:
                                al_destroy_display(janela);
                                sair_allegro = true;
                            break;
                        }
                    }
                }
            }
}

#endif // GRAFIC_H_INCLUDED
