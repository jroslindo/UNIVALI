/// /////////////////////////////////////////////////////// ///
/// UNIVERSIDADE DO VALE DO ITAJA� - UNIVALI                ///
/// CURSO DE ENGENHARIA DE COMPUTA��O - ESTRUTURA DE DADOS  ///
/// PROFESSOR: RAFAEL BALLOTTIN MARTINS                     ///
/// ALUNOS: GUSTAVO COPINI DECOL E JO�O PAULO ROSLINDO      ///
/// /////////////////////////////////////////////////////// ///
#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>

using namespace std;

#include "TADCalculadora.h"
#include "Grafic.h"

int main()
{
    int numero;
    string expressao;
    bool sair=false;
    while (sair==false){ //numero � a escolha do menu
        numero = menu ();
        switch (numero){ //funcao de executar, calcular arvore etc...
        case 0:
            expressao = janela_de_entrada();
            while(verifica(expressao) == false || verifica_arvore(arruma_expressao(expressao)) == false){
                errado();
                expressao = janela_de_entrada();
            }
            executar_allegro(expressao);
        break;
        case 1: //instrucoes
            instrucoes();
        break;
        case 2: //creditos
            creditos();
        break;
        case 3: // sair do while e do programa
            sair =true;
        break;

        }
    }
}
