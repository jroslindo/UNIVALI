#ifndef TADARVOREBINARIA_H_INCLUDED
#define TADARVOREBINARIA_H_INCLUDED
#include <stdlib.h>
#include <time.h>

struct TPessoa{

    int codigo;

};

template <typename TIPO>
struct TNo{

    TIPO dado;
    int balanceamento
    TNo <TIPO> *direita;
    TNo <TIPO> *esquerda;

};

template <typename TIPO>
struct TArvore{

    TNo <TIPO> *raiz;

};

template <typename TIPO>
void inicializar (TArvore <TIPO> &no){

    no.raiz = NULL;

}


    TNo <TIPO> *apagar = no;
    TNo <TIPO> *maior = no->esquerda;

    if(maior==NULL){
        no=no->direita;
        delete(apagar);
        return;
    }

    TNo <TIPO> *pai = NULL;
    while(maior->direita!=NULL){
        pai = maior;
        maior = maior->direita;
    }

    maior->direita = no->direita;
    if(pai!=NULL){
        pai->direita = maior->esquerda;
        maior->esquerda = no->esquerda;
    }

    apagar = no;
    no = maior;
    delete (apagar)template <typename TIPO>
void imprimirArvore(TNo <TIPO> *&no){

    if(no!=NULL){
        cout<<no->dado.codigo<<endl;
        imprimirArvore(no->esquerda);
        imprimirArvore(no->direita);
    }

}

#endif // TADARVOREBINARIA_H_INCLUDED
