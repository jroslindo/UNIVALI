///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////Universidade do Vale do Itajai//////////////////////////////////////////////
/////////////Estrutura de Dados////////////////////////////////////////////////////////////////////
/////////////Professor: Rafael Ballotin////////////////////////////////////////////////////////////
/////////////Alunos: Jo�o Paulo Roslindo e Gustavo Copini Decol ///////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef LISTA_GENERICA_H_INCLUDED
#define LISTA_GENERICA_H_INCLUDED

template <typename TIPO>
struct TElemento{
    TIPO dado;
    TElemento <TIPO> *proximo;
    TElemento <TIPO> *anterior;
};

template <typename TIPO>
struct Tlista{
    TElemento <TIPO> *inicio;
    TElemento <TIPO> *fim;
};

template <typename TIPO>
void inicializar (Tlista <TIPO> &p){

    p.inicio=NULL;
    p.fim = NULL;
}

//basico das listas (acima)

template <typename TIPO>
TElemento <TIPO> *  novo_elemento_lista (TIPO dado){

    TElemento <TIPO> * novo = new TElemento<TIPO>; //fun��o para o encapsulamento

    novo -> dado = dado; //agr com o anterior
    novo -> proximo = NULL;
    novo -> anterior = NULL;

    return novo;
}

template <typename TIPO>
bool insereFinal (Tlista <TIPO> &lista, TIPO dado){

    TElemento<TIPO> *nav = lista.inicio; //nav

    if(lista.inicio != NULL){

        if (lista.fim -> proximo !=NULL){
            return false;

        }else{
                TElemento <TIPO> * novo = novo_elemento_lista(dado); //encapsulamento
                lista.fim ->proximo = novo; //apontamentos com o fim da lista
                novo->anterior = lista.fim;
                lista.fim=novo;
                return true;
            }

    }else{ //caso a lista esteja vazia
        TElemento <TIPO> * novo = novo_elemento_lista(dado); // encapsulamento
        lista.inicio = novo;
        lista.fim = novo;
        return true;
    }


}

template <typename TIPO>
bool removeFinal (Tlista <TIPO> &lista){

    if(lista.inicio == NULL){
        return false;
    }else{
        lista.fim = lista.fim->anterior; //trocando o fim da lista
        delete lista.fim->proximo;
        lista.fim->proximo = NULL; //removeu

        return true;
    }
}

template <typename TIPO>
bool insereInicio (Tlista <TIPO> &lista, TIPO dado){

    TElemento <TIPO> * novo = novo_elemento_lista(dado); // novo dado

    if(lista.inicio==NULL){ //inser��o com lista vazia
        lista.inicio = novo;
        return true;
    }else{
        novo -> anterior = NULL;    //inser��o com lista tendo algo
        novo -> proximo = lista.inicio;
        lista.inicio= novo;
        return true;
    }
}

template <typename TIPO>
bool removeInicio (Tlista <TIPO> &lista){

    if(lista.inicio==NULL){
        return false;
    }else{
        TElemento<TIPO> *removedor = lista.inicio;
        lista.inicio = removedor -> proximo; //removeu
        lista.inicio -> anterior = NULL;
        delete removedor;

        return true;
    }
}

template <typename TIPO>
bool inserePosi (Tlista <TIPO> &lista,TIPO dado, int p){

int qtt=contaLista(lista),i=0; //variaveis

TElemento<TIPO> *novo = novo_elemento_lista(dado); //novo elemento
TElemento<TIPO> *nav = lista.inicio; //nav
TElemento<TIPO> *anterior; // o anterior

    if(lista.inicio==NULL || p > qtt || p < 0 ){
        return false;
    }
    if(p==qtt){ //inserir no final
        insereFinal(lista,dado);
        return true;
    }if(p==0){ //inserir no inicio
        insereInicio(lista,dado);
        return true;
    }else{
        while (i<p){ // procura o anterior
            anterior = nav;
            nav = nav -> proximo;
            i++;
        }
            novo -> anterior = anterior; //troca
            novo -> proximo = nav;
            anterior -> proximo = novo;
            nav -> anterior = novo;
            return true;
    }
}

template <typename TIPO>
bool removePosi (Tlista <TIPO> &lista, int p){

int qtt=contaLista(lista),i=0; //variaveis

TElemento<TIPO> *nav = lista.inicio;
TElemento<TIPO> *anterior;
TElemento<TIPO> *depois;

    if(lista.inicio==NULL || p > qtt || p < 0 ){
        return false;
    }
    if(p==qtt){ //mesmo sistema da insere posi
        removeFinal(lista);
        return true;
    }if(p==0){
        removeInicio(lista);
        return true;
    }else{
        while (i<p){
            anterior = nav;
            nav = nav -> proximo;
            depois = nav -> proximo;
            i++;
        }
            anterior ->proximo = depois;
            depois ->anterior = anterior;
            delete nav;

            return true;
    }
}

template <typename TIPO>
int contaLista (Tlista <TIPO> &lista){ //fun��o para contar a lista

    int qtt=0;

    TElemento<TIPO> *nav = lista.inicio;

    if(lista.inicio==NULL){
        cout<< "Lista Vazia!" << endl;
    }else{

        while (nav -> proximo != NULL){
            nav = nav ->proximo;
            qtt++;
        }

    return qtt;
    }


}


#endif // LISTA_GENERICA_H_INCLUDED
