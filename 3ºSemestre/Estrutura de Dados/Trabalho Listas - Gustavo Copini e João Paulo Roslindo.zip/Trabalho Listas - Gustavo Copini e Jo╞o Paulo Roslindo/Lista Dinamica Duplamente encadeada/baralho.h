///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////Universidade do Vale do Itajai//////////////////////////////////////////////
/////////////Estrutura de Dados////////////////////////////////////////////////////////////////////
/////////////Professor: Rafael Ballotin////////////////////////////////////////////////////////////
/////////////Alunos: Jo�o Paulo Roslindo e Gustavo Copini Decol ///////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef BARALHO_H_INCLUDED
#define BARALHO_H_INCLUDED

#include "TADDuplamenteEncadeado.h"

struct TCarta{

    string naipe;
    int valor;

};

bool imprimeBaralho (Tlista <TCarta> &lista){ //fun��o para ve ro baralho

        TElemento<TCarta> *nav = lista.inicio;
        if(lista.inicio==NULL){
            return false;
        }else{
            while (nav != NULL){
                cout <<"\n----------------------------------------------------\n";
                cout << "Naipe: " << nav->dado.naipe << endl;
                cout << "valor: " << nav->dado.valor << endl;
                cout <<"\n----------------------------------------------------";
                nav = nav ->proximo;
            }
            return true;
        }
}

void montaBaralho (Tlista <TCarta>  &lista){  //fun��o para montar o baralho

    int i;
    TCarta card;
    for (i=1; i<=13; i++)
    {
        card.naipe = "Ouro";
        card.valor = i;
        insereFinal(lista,card);
    }

    for (i=1; i<=13; i++)
    {
        card.naipe = "Copas";
        card.valor = i;
        insereFinal(lista,card);
    }

    for (i=1; i<=13; i++)
    {
        card.naipe = "Espadas";
        card.valor = i;
        insereFinal(lista,card);
    }
    for (i=1; i<=13; i++)
    {
        card.naipe = "Paus";
        card.valor = i;
        insereFinal(lista,card);
    }
}

void bubbleSort (Tlista <TCarta> &lista){

    Tlista <TCarta> Ouro, Paus, Espadas, Copas; //variaveis para separar
    inicializar(Ouro);
    inicializar(Paus);
    inicializar(Espadas);
    inicializar(Copas);
    TCarta temp;  //temporaria
    TElemento <TCarta> *nav = lista.inicio; //navegador


    int i,j, indice,fim=0,encher=0, quantidade; //variaveis para ajuda

    quantidade = contaLista(lista); //retorna o valor de cartas na lista


    for (i=0; i<quantidade; i++){
        if ( nav->dado.naipe == "Ouro")  //colocando as cartas no
                insereFinal(Ouro, nav->dado);

        if ( nav->dado.naipe == "Paus")
                insereFinal(Paus, nav->dado);

        if ( nav->dado.naipe == "Espadas")
                insereFinal(Espadas, nav->dado);

        if ( nav->dado.naipe == "Copas")
                insereFinal(Copas, nav->dado);



        nav= nav-> proximo; //nav andando

    }

    i=1;
    while (i==1){ //ordena valor

        fim=0;
        nav= Ouro.inicio;
        for(j=0;j<12;j++){

        if(nav->proximo->dado.valor < nav->dado.valor   && nav->proximo != NULL) { //ordenando
            temp=nav->proximo->dado;
            nav->proximo->dado = nav->dado; //reapontamentos
            nav->dado = temp;
        }else{
            fim++;
        }
        if (fim == 12)
            i=0;
            nav=nav->proximo; //nav andando
        }
    }

    lista.inicio = Ouro.inicio; //reapontando depois de ordenada

    nav->proximo = Copas.inicio;
    Copas.inicio->anterior = nav;

    i=1;
    while (i==1){ //ordena valor

        fim=0;
        nav= Copas.inicio;
        for(j=0;j<12;j++){

        if(nav->proximo->dado.valor < nav->dado.valor   && nav->proximo != NULL) { //mesmo processo
            temp=nav->proximo->dado;
            nav->proximo->dado = nav->dado;
            nav->dado = temp;

        }else{
            fim++;
        }
        if (fim == 12)
            i=0;
            nav=nav->proximo;


        }
    }

    //************************************************ GRUDA LISTA
    nav->proximo = Paus.inicio;
    Paus.inicio->anterior = nav;

    //************************************************ GRUDA LISTA

    i=1;
    while (i==1){ //ordena valor

        fim=0;
        nav= Paus.inicio;
        for(j=0;j<12;j++){

        if(nav->proximo->dado.valor < nav->dado.valor   && nav->proximo != NULL) {
            temp=nav->proximo->dado;
            nav->proximo->dado = nav->dado;
            nav->dado = temp;

        }else{
            fim++;
        }
        if (fim == 12)
            i=0;
            nav=nav->proximo;


        }
    }
    //************************************************ GRUDA LISTA
    nav->proximo = Espadas.inicio;
    Espadas.inicio->anterior = nav;
    //************************************************ GRUDA LISTA
    i=1;
    while (i==1){ //ordena valor

        fim=0;
        nav= Espadas.inicio;
        for(j=0;j<12;j++){

        if(nav->proximo->dado.valor < nav->dado.valor   && nav->proximo != NULL) {
            temp=nav->proximo->dado;
            nav->proximo->dado = nav->dado;
            nav->dado = temp;

        }else{
            fim++;
        }
        if (fim == 12)
            i=0;

        nav=nav->proximo;


        }
    }
    lista.fim=nav; //lista fim recebendo o fim da nav e deletando o navegador
    delete nav;

}

void mergeS(Tlista <TCarta> &teste){

   int i=0,j,k,fim,meio;

   TElemento <TCarta> vetorTemp[13];
   vetorTemp[0].proximo = NULL;

   TElemento <TCarta> *nav = teste.inicio; //navegador
   TElemento <TCarta> armazena; //armazenador usado na troca

   while (i<13){
    vetorTemp[i].dado.naipe = nav->dado.naipe; //separando em vetor
    vetorTemp[i].dado.valor = nav->dado.valor;
    i++;
    nav=nav->proximo; //nav andando
   }

   i=1;
    while (i==1){ //ordena valor

        fim=0;

        for(j=0;j<12;j++){

        if(vetorTemp[j+1].dado.valor < vetorTemp[j].dado.valor) { //teste pra troca
            armazena.dado= vetorTemp[j+1].dado;
            vetorTemp[j+1].dado=vetorTemp[j].dado; //troca
            vetorTemp[j].dado=armazena.dado;
        }else{
            fim++;
        }
        if (fim == 12)
            i=0;

        }
    }
    inicializar(teste); //zerando  a lista
    for(i=0; i<13; i++){
        insereFinal(teste, vetorTemp[i].dado); //recolocando na lista
    }

}

void mergeSort (Tlista <TCarta> &lista){

int i,j, indice,fim=0,contador, quantidade=contaLista(lista);

    Tlista <TCarta> Ouro, Paus, Espadas, Copas; // variaveis pra armazenar
    inicializar(Ouro);
    inicializar(Paus);
    inicializar(Espadas);
    inicializar(Copas);
    TElemento <TCarta> *nav = lista.inicio; //nav

    for (i=0; i<quantidade; i++){
        if ( nav->dado.naipe == "Ouro")         //separa em vetores
            insereFinal(Ouro, nav->dado);


        if ( nav->dado.naipe == "Paus")
            insereFinal(Paus, nav->dado);


        if ( nav->dado.naipe == "Espadas")
            insereFinal(Espadas, nav->dado);


        if ( nav->dado.naipe == "Copas")
            insereFinal(Copas, nav->dado);


        nav= nav-> proximo; //navegador andando

    }

    mergeS(Ouro);//ordena por valor


        lista.inicio = Ouro.inicio; //reaponta pra lista
        nav=lista.inicio;
        while (nav->proximo != NULL)
            nav=nav->proximo;


    mergeS(Copas); //ordena por valor

        nav->proximo = Copas.inicio;
        Copas.inicio->anterior = nav;
        while (nav->proximo != NULL)
            nav=nav->proximo;

    mergeS(Espadas); //ordena valor

        nav->proximo = Espadas.inicio;
        Espadas.inicio->anterior = nav; //reaponta

        while (nav->proximo != NULL)
            nav=nav->proximo;

    mergeS(Paus); //ordena valor

        nav->proximo = Paus.inicio; //reaponta
        lista.fim= Paus.fim;    //aponta o fim da lista
        Paus.fim->anterior = lista.fim; //aponta o fim da lista





}








#endif // BARALHO_H_INCLUDED
