///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////Universidade do Vale do Itajai//////////////////////////////////////////////
/////////////Estrutura de Dados////////////////////////////////////////////////////////////////////
/////////////Professor: Rafael Ballotin////////////////////////////////////////////////////////////
/////////////Alunos: Jo�o Paulo Roslindo e Gustavo Copini Decol ///////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef BARALHO_H_INCLUDED
#define BARALHO_H_INCLUDED
#include "TADEncadeada.h"

struct TCarta{

    string naipe;
    int valor;

};

bool imprimeBaralho (Tlista <TCarta> &lista){ //fun��o de utilidade para ver o baralho

        TElemento<TCarta> *nav = lista.inicio; //criando um navegador
        if(lista.inicio==NULL){
            return false;
        }else{
            while (nav != NULL){
                cout <<"\n----------------------------------------------------\n"; //imprimindo na tela
                cout << "Naipe: " << nav->dado.naipe << endl;
                cout << "valor: " << nav->dado.valor << endl;
                cout <<"\n----------------------------------------------------";
                nav = nav ->proximo; // navegador andando
            }
            return true;
        }
}

void montaBaralho (Tlista <TCarta>  &lista){

    int i;
    TCarta card;
    for (i=1; i<=13; i++)
    {
        card.naipe = "Ouro"; //criando uma card q ser� inserida
        card.valor = i;
        insereFinal(lista,card); //fazendo uso da fun��o para facilitar
    }
    for (i=1; i<=13; i++) //segue a mesma ideia
    {
        card.naipe = "Copas";
        card.valor = i;
        insereFinal(lista,card);
    }
    for (i=1; i<=13; i++)
    {
        card.naipe = "Espadas";
        card.valor = i;
        insereFinal(lista,card);
    }
    for (i=1; i<=13; i++)
    {
        card.naipe = "Paus";
        card.valor = i;
        insereFinal(lista,card);
    }
}

void bubbleSort (Tlista <TCarta> &lista){

    Tlista <TCarta> Ouro, Paus, Espadas, Copas; //criando listas q ser�o usadas para armazenar
    inicializar(Ouro); //inicializando listas, muito importante
    inicializar(Paus);
    inicializar(Espadas);
    inicializar(Copas);
    TCarta temp; //carta temporaria para armazenar
    TElemento <TCarta> *nav = lista.inicio; //navegador recebendo o inicio da lista


    int i,j,fim=0, quantidade; // variaveis de utilidade

    quantidade = contaLista(lista); // fun��o feita para contar cartas na lista


    for (i=0; i<quantidade; i++){
        if ( nav->dado.naipe == "Ouro") // se o dado for ouro
            insereFinal(Ouro, nav->dado);// usando fun��o para por na lista ouro

        if ( nav->dado.naipe == "Paus")
            insereFinal(Paus, nav->dado);// usando fun��o para por na lista Paus

        if ( nav->dado.naipe == "Espadas")
            insereFinal(Espadas, nav->dado);


        if ( nav->dado.naipe == "Copas")
            insereFinal(Copas, nav->dado);


        nav= nav-> proximo;  //navegador anda percorrendo a lista

    }

    i=1;
    while (i==1){ //ordena valor

        fim=0;
        nav= Ouro.inicio; //nav agr � do ouro
        for(j=0;j<12;j++){
        if(nav->proximo->dado.valor < nav->dado.valor   && nav->proximo != NULL) { //checagem de maior q
            temp=nav->proximo->dado; //simples troca usando o temp
            nav->proximo->dado = nav->dado;
            nav->dado = temp;
        }else{
            fim++; //caso tudo foi checado e n foram feito 12 altera��es
        }
        if (fim == 12) //o i pode sair
            i=0;

        nav=nav->proximo; //nav andando
        }
    }

    lista.inicio = Ouro.inicio; //encadeando a lista principal com o ouro, simples ligamento
    nav->proximo = Copas.inicio; //agr o nav e do copas E ja encadeou o ouro ao copas
    i=1;
    while (i==1){ //ordena valor

        fim=0;
        nav= Copas.inicio;
        for(j=0;j<12;j++){

        if(nav->proximo->dado.valor < nav->dado.valor   && nav->proximo != NULL) {  // mesmo processo de ordena��o igual ao de cima
            temp=nav->proximo->dado;
            nav->proximo->dado = nav->dado;
            nav->dado = temp;
        }else{
            fim++;
        }
        if (fim == 12)
            i=0;
            nav=nav->proximo;


        }
    }
    nav ->proximo = Paus.inicio;  //encadeando
    i=1;
    while (i==1){ //ordena valor  // mesmo processo

        fim=0;
        nav= Paus.inicio;
        for(j=0;j<12;j++){

        if(nav->proximo->dado.valor < nav->dado.valor   && nav->proximo != NULL) {
            temp=nav->proximo->dado;
            nav->proximo->dado = nav->dado;
            nav->dado = temp;

        }else{
            fim++;
        }
        if (fim == 12)
            i=0;
            nav=nav->proximo;


        }
    }
    nav->proximo= Espadas.inicio; //encadeando
    i=1;
    while (i==1){ //ordena valor

        fim=0;
        nav= Espadas.inicio;
        for(j=0;j<12;j++){

        if(nav->proximo->dado.valor < nav->dado.valor   && nav->proximo != NULL) {
            temp=nav->proximo->dado;
            nav->proximo->dado = nav->dado;
            nav->dado = temp;

        }else{
            fim++;
        }
        if (fim == 12)
            i=0;

        nav=nav->proximo;


        }
    }
    //ao final, a lista esta pronta simplesmente pelos encadeamentos!!!




}

void mergeS(Tlista <TCarta> &teste, int posicaoFim ){

   int i=0,j,fim;

   TElemento <TCarta> vetorTemp[13]; // vetor usado para DIVIDIR
   vetorTemp[0].proximo = NULL;

   TElemento <TCarta> *nav = teste.inicio;
   TElemento <TCarta> armazena; //armazenador temporario

   while (i<13){
    vetorTemp[i].dado.naipe = nav->dado.naipe; //atribui��o e distribui��o de cada carta pra cada parte do vetor
    vetorTemp[i].dado.valor = nav->dado.valor;
    i++; //i anda
    nav=nav->proximo; //nav anda
   }

   i=1;
    while (i==1){ //SIMPLES ORDENA��O SIMILAR AO BUBBLE

        fim=0;

        for(j=0;j<12;j++){

        if(vetorTemp[j+1].dado.valor < vetorTemp[j].dado.valor) {
            armazena.dado= vetorTemp[j+1].dado;
            vetorTemp[j+1].dado=vetorTemp[j].dado;
            vetorTemp[j].dado=armazena.dado;
        }else{
            fim++;
        }
        if (fim == 12)
            i=0;
        }
    }
    inicializar(teste); //zeramos o teste, afinal agr tudo esta dentro do vetorTemp
    for(i=0; i<13; i++){
        insereFinal(teste, vetorTemp[i].dado);  //devolve o teste, ele se tornara o ouro, paus, copas e espadas
    }
    //processo feito com base no dividir e conquistar (ordenar)
}

void mergeSort (Tlista <TCarta> &lista){

int i,contador, quantidade=contaLista(lista);

    Tlista <TCarta> Ouro, Paus, Espadas, Copas; //vetores de armazenamento
    inicializar(Ouro);
    inicializar(Paus);
    inicializar(Espadas);
    inicializar(Copas);
    TElemento <TCarta> *nav = lista.inicio;

    for (i=0; i<quantidade; i++){
        if ( nav->dado.naipe == "Ouro")
             insereFinal(Ouro, nav->dado);

        if ( nav->dado.naipe == "Paus")
            insereFinal(Paus, nav->dado);



        if ( nav->dado.naipe == "Espadas")
            insereFinal(Espadas, nav->dado);



        if ( nav->dado.naipe == "Copas")
            insereFinal(Copas, nav->dado);

        nav= nav-> proximo;
    }

    contador=contaLista(Ouro);
    mergeS(Ouro,contador); //chama o mergeS


        lista.inicio = Ouro.inicio; //encadeando e percorrendo o vetor  // processo se repete
        nav=lista.inicio;
        while (nav->proximo != NULL)
            nav=nav->proximo;

    contador=contaLista(Espadas);
    mergeS(Espadas,contador);

        nav->proximo = Espadas.inicio;
        while (nav->proximo != NULL)
            nav=nav->proximo;

    contador=contaLista(Copas);
    mergeS(Copas,contador);

        nav->proximo=Copas.inicio;
        while (nav->proximo != NULL)
            nav=nav->proximo;


    contador=contaLista(Paus);
    mergeS(Paus,contador);

        nav->proximo = Paus.inicio;

    //ao final ela ja estar� encadeada!!!


}







#endif // BARALHO_H_INCLUDED
