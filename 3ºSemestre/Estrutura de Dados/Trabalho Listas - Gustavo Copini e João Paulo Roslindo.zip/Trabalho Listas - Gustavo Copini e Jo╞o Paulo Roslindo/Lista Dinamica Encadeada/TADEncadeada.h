///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////Universidade do Vale do Itajai//////////////////////////////////////////////
/////////////Estrutura de Dados////////////////////////////////////////////////////////////////////
/////////////Professor: Rafael Ballotin////////////////////////////////////////////////////////////
/////////////Alunos: Jo�o Paulo Roslindo e Gustavo Copini Decol ///////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef LISTA_GENERICA_H_INCLUDED
#define LISTA_GENERICA_H_INCLUDED

template <typename TIPO>
struct TElemento{
    TIPO dado;
    TElemento <TIPO> *proximo;
};

template <typename TIPO>
struct Tlista{
    TElemento <TIPO> *inicio;
};
// apos as estruturas basicas para criar lista

template <typename TIPO>
void inicializar (Tlista <TIPO> &p){

    p.inicio=NULL; //inicializa lista
}

template <typename TIPO>
TElemento <TIPO> *  novo_elemento_lista (TIPO dado){

    TElemento <TIPO> * novo = new TElemento<TIPO>; //fun��o q cria os elementos (encapsula)

    novo -> dado = dado;
    novo -> proximo = NULL;

    return novo;
}

template <typename TIPO>
bool insereFinal (Tlista <TIPO> &lista, TIPO dado){

    TElemento<TIPO> *nav = lista.inicio; //cria o elemento

    if(lista.inicio != NULL){
        while (nav -> proximo != NULL) // percorre os elementos at� chegar no ultimo
            nav = nav ->proximo;

        if (nav -> proximo !=NULL){
            return false;

        }else{
                TElemento <TIPO> * novo = novo_elemento_lista(dado); //crio o dado e encapsulo
                novo -> proximo = nav -> proximo; //insiro o novo com base no navegador
                nav -> proximo = novo;
                return true;
            }

    }else{ //se a lista n tiver dado ainda
        TElemento <TIPO> * novo = novo_elemento_lista(dado); //crio o dado e encapsulo
        lista.inicio = novo; //simplesmente encadeio o inicio da lista ao dado novo
        return true;
    }
}

template <typename TIPO>
bool removeFinal (Tlista <TIPO> &lista){

    TElemento<TIPO> *nav = lista.inicio; //navegador
    TElemento<TIPO> *ultimo; //procurando o ultimo elemento
    if(lista.inicio == NULL){
        return false;
    }else{
        while(nav -> proximo != NULL){ //aki o ultimo se tornara o novo ultimo elemento da lista
            ultimo = nav;
            nav=nav -> proximo;
        }
        ultimo->proximo= NULL;  //atribui��es
        delete nav;
        return true;
    }
}

template <typename TIPO>
bool insereInicio (Tlista <TIPO> &lista, TIPO dado){

    TElemento <TIPO> * novo = novo_elemento_lista(dado); // crio o novo

    if(lista.inicio==NULL){ //se for o primeiro apenas insiro
        lista.inicio = novo;
        return true;
    }else{
        novo -> proximo = lista.inicio; //inserindo no inicio e reapontando
        lista.inicio = novo;
        return true;
    }
}

template <typename TIPO>
bool removeInicio (Tlista <TIPO> &lista){

    if(lista.inicio==NULL){
        return false;
    }else{
        TElemento<TIPO> *removedor = lista.inicio; // crio um removedor
        lista.inicio = removedor ->proximo; //simplesmente perco o dado removido
        delete removedor; //deleto esse dado
        return true;
    }
}

template <typename TIPO>
bool inserePosi (Tlista <TIPO> &lista,TIPO dado, int p){

int qtt=contaLista(lista),i=0;

TElemento<TIPO> *novo = novo_elemento_lista(dado); //novo
TElemento<TIPO> *nav = lista.inicio; // navegador
TElemento<TIPO> *anterior; //o anterior a posi

    if(lista.inicio==NULL || p > qtt || p < 0 ){
        return false;
    }
    if(p==qtt){ //se a posi for a ultima
        insereFinal(lista,dado);
        return true;
    }if(p==0){ //se a posi for a inicial
        insereInicio(lista,dado);
        return true;
    }else{
        while (i<p){ //se n percorrer ate a posi
            anterior = nav;
            nav = nav -> proximo;
            i++;
        }
            novo -> proximo = anterior -> proximo; // insere
            anterior -> proximo = novo;
            return true;
    }
}

template <typename TIPO>
bool removePosi (Tlista <TIPO> &lista, int p){

int qtt=contaLista(lista),i=0;

TElemento<TIPO> *nav = lista.inicio; //nav
TElemento<TIPO> *depois; // o depois da posi

    if(lista.inicio==NULL || p > qtt || p < 0 ){
        return false;
    }
    if(p==qtt){ //para remover a posi fim
        removeFinal(lista);
        return true;
    }if(p==0){ //para remover a posi inicial
        removeInicio(lista);
        return true;
    }else{
        while (i<p){ //navegar ate a posi
            depois = nav;
            nav = nav -> proximo;
            i++;
        }
            depois -> proximo = nav ->proximo; //encadeamento perdendo o dado a ser removido
            delete nav; //deletando esse dado
            return true;
    }
}

template <typename TIPO>
int contaLista (Tlista <TIPO> &lista){ //fun��o para contar a minha lista

    int qtt=0;
    TElemento<TIPO> *nav = lista.inicio;
    if(lista.inicio==NULL){ //caso esteja vazia
        cout<< "Lista Vazia!" << endl;
    }else{
        while (nav != NULL){ //simplesmente cada vez q o nav anda adicionamos um ao qtt
            nav = nav ->proximo;
            qtt++;
        }
    return qtt; //qtt � quantos dados tem a lista
    }
}

#endif // LISTA_GENERICA_H_INCLUDED
