///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////Universidade do Vale do Itajai//////////////////////////////////////////////
/////////////Estrutura de Dados////////////////////////////////////////////////////////////////////
/////////////Professor: Rafael Ballotin////////////////////////////////////////////////////////////
/////////////Alunos: Jo�o Paulo Roslindo e Gustavo Copini Decol ///////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef BARALHO_H_INCLUDED
#define BARALHO_H_INCLUDED
#include "TADListaEstatica.h"

struct TCarta{ // dado principal

    string naipe;
    int valor;

};

template <typename TIPO, int MAX> //template
void montaBaralho(Tlista <TIPO,MAX> &l){


    int c=1;


    for(c=1;c<=13;c++){                                 //inser��o de 13 em 13 para cada naipe
        l.elementos[l.quantidade].dado.valor=c;
        l.elementos[l.quantidade].dado.naipe="Ouro";
        l.quantidade++;
    }

    for(c=1;c<=13;c++){
        l.elementos[l.quantidade].dado.valor=c;
        l.elementos[l.quantidade].dado.naipe="Copas";
        l.quantidade++;
    }

    for(c=1;c<=13;c++){
        l.elementos[l.quantidade].dado.valor=c;
        l.elementos[l.quantidade].dado.naipe="Paus";
        l.quantidade++;
    }


    for(c=1;c<=13;c++){
        l.elementos[l.quantidade].dado.valor=c;
        l.elementos[l.quantidade].dado.naipe="Espadas";
        l.quantidade++;
    }




}

template <typename TIPO, int MAX>
void imprimeBaralho(Tlista <TIPO,MAX> &l){

    int i;

    for(i=0;i<l.quantidade;i++){
        cout <<"\n-------------------------------------";
        cout <<"\nValor: "<<l.elementos[i].dado.valor;
        cout <<"\nNaipe: "<<l.elementos[i].dado.naipe;
        cout <<"\n-------------------------------------";

    }

}

template <typename TIPO, int MAX>
void embaralha (Tlista <TIPO,MAX> &l){

    int qt=0,al1,al2,passou, n_vezes;

    TElemento <TIPO> e; //dado usado como temporario

    srand (time(NULL));
    n_vezes=rand() % 1000+1; //sorteando o numero de vezes que far� o processo para uma ordena��o realmente funcional

    while(qt<=n_vezes){

        passou=0; // variavel de checagem
        al1=rand()% 52;
        al2=rand()% 52;

        if(al1==al2){ // os numeros sorteados sejam iguais
            passou++;
        }

        if(passou==0){
            e=l.elementos[al1];  //troca posi
            l.elementos[al1]=l.elementos[al2];
            l.elementos[al2]=e;
            qt++;
        }
    }
}

template <typename TIPO, int MAX>
void bubbleSort (Tlista <TIPO,MAX> &l){

    int i,j,fim=0,c=0,e=0,o=0, p=0,encher=0;

    TElemento <TCarta> Ouro[13];  //listas usadas para armazenamento
    TElemento <TCarta> Paus[13];
    TElemento <TCarta> Copas[13];
    TElemento <TCarta> Espadas[13];
    TElemento <TIPO> dado; //dado usado para armazenamento


    for (i=0; i<l.quantidade; i++){
        if ( l.elementos[i].dado.naipe == "Ouro"){  //processo de jogar cartas ouro no vetor da lista ouro
            Ouro[o] = l.elementos[i];
            o++;
        }

        if ( l.elementos[i].dado.naipe == "Espadas"){
            Espadas[e] = l.elementos[i];
            e++;
        }

        if ( l.elementos[i].dado.naipe == "Copas"){
            Copas[c] = l.elementos[i];
            c++;
        }

        if ( l.elementos[i].dado.naipe == "Paus"){
            Paus[p] = l.elementos[i];
            p++;
        }
    }

    i=1;
    while (i==1){ //ordena por valor o ouro e assim por diante
        fim=0;
        for(j=0;j<12;j++){

        if(Ouro[j+1].dado.valor < Ouro[j].dado.valor) {
            dado = Ouro[j];
            Ouro[j]=Ouro[j+1];
            Ouro[j+1]=dado;
        }else{
            fim++;
        }
        if (fim == 12)
            i=0;

        if (i==0){
            for (i=0; i<13; i++){
                if (Ouro[i].dado.naipe == "Ouro"){  // joga na lista principal
                l.elementos[i]= Ouro[i];
                encher++; //variavel do baralho cheio  // o encher serve para dizer em que posi��o do baralho ser� colocada  a carta
                }
            }
        }
        }

    }


    i=1;
    while (i==1){ //ordena valor
        fim=0;
        for(j=0;j<12;j++){

        if(Espadas[j+1].dado.valor < Espadas[j].dado.valor) {
            dado = Espadas[j];
            Espadas[j]=Espadas[j+1];
            Espadas[j+1]=dado;
        }else{
            fim++;
        }
        if (fim == 12)
            i=0;
        }

        if (i==0){
            for (i=0; i<13; i++){
                if (Espadas[i].dado.naipe == "Espadas"){ // joga na lista principal
                l.elementos[encher]= Espadas[i];
                encher++;
                }

            }
        }

    }

    i=1;
    while (i==1){ //ordena valor
        fim=0;
        for(j=0;j<12;j++){

        if(Copas[j+1].dado.valor < Copas[j].dado.valor) {
            dado = Copas[j];
            Copas[j]=Copas[j+1];
            Copas[j+1]=dado;
        }else{
            fim++;
        }
        if (fim == 12)
            i=0;
        }

        if (i==0){
            for (i=0; i<13; i++){
                if (Copas[i].dado.naipe == "Copas"){ // joga na lista principal
                l.elementos[encher]= Copas[i];
                encher++;
                }

            }
        }

    }

    i=1;
    while (i==1){ //ordena valor
        fim=0;
        for(j=0;j<12;j++){

        if(Paus[j+1].dado.valor < Paus[j].dado.valor) {
            dado = Paus[j];
            Paus[j]=Paus[j+1];
            Paus[j+1]=dado;
        }else{
            fim++;
        }
        if (fim == 12)
            i=0;
        }

        if (i==0){
            for (i=0; i<13; i++){
                if (Paus[i].dado.naipe == "Paus"){ // joga na lista principal
                l.elementos[encher]= Paus[i];
                encher++;
                }
            }
        }

    }


}

template <typename TIPO, int MAX>
void mergeS(Tlista <TIPO,MAX> &teste, int posiInicio, int posiFim ){

   int i,j,k,meio; // i,j,k s�o contadores usados nas atribui��es dos vetores

   Tlista <TCarta, 13> vetorTemp; // a tlista para armazenar temporariamente

   if ( posiInicio == posiFim )
    return;

   meio = ( posiInicio+posiFim )/2;  //parte recursiva, dividir e conquisar
   mergeS( teste, posiInicio, meio);
   mergeS( teste, meio+1,posiFim );

   k = 0;
   j = meio+1;
   i = posiInicio;


   while( i < meio+1 || j  < posiFim+1 ) // meio +1 pra passar da metade
   {
      if ( i == meio+1 ) // i e maior que a metade
      {
       vetorTemp.elementos[k] = teste.elementos[j]; //atribui��o
       j++; //incrementa-se essas duas variaveis pois foi inserido
       k++; // assim n tem problema de colocar um dado sobre o outro
      }
      else
      {
         if (j==posiFim+1) // j e maior que a metade
         {
            vetorTemp.elementos[k] = teste.elementos[i]; //atribui��o para nossa lista
            i++;
            k++;
         }
         else
         {
            if (teste.elementos[i].dado.valor < teste.elementos[j].dado.valor) //ordena
            {
               vetorTemp.elementos[k] = teste.elementos[i];
               i++;
               k++;
            }
            else
            {
              vetorTemp.elementos[k] = teste.elementos[j];
              j++;
              k++;
            }
         }
      }
   }


   for( i = posiInicio; i <= posiFim; i++ ) // voltando para a o vetor teste que se tornar� o vetor ouro,paus, copas, espadas...
   {
      if(vetorTemp.elementos[i-posiInicio].dado.naipe == "Ouro" || vetorTemp.elementos[i-posiInicio].dado.naipe == "Copas" || vetorTemp.elementos[i-posiInicio].dado.naipe == "Paus" || vetorTemp.elementos[i-posiInicio].dado.naipe == "Espadas")
        teste.elementos[i] = vetorTemp.elementos[i-posiInicio]; // atribuindo para o teste
   }

}

template <typename TIPO, int MAX>
void mergeSort (Tlista <TIPO,MAX> &l){

    int i,j,c=0,e=0,o=0, p=0;

    Tlista <TCarta,13> Ouro; // vetores de armazenamento
    Tlista <TCarta,13> Paus;
    Tlista <TCarta,13> Copas;
    Tlista <TCarta,13> Espadas;

    for (i=0; i<l.quantidade; i++){
        if ( l.elementos[i].dado.naipe == "Ouro"){ //atribui��es para os vetores
            Ouro.elementos[o] = l.elementos[i];
            o++; //contadores de cartas
        }

        if ( l.elementos[i].dado.naipe == "Espadas"){
            Espadas.elementos[e] = l.elementos[i];
            e++;
        }

        if ( l.elementos[i].dado.naipe == "Copas"){
            Copas.elementos[c] = l.elementos[i];
            c++;
        }

        if ( l.elementos[i].dado.naipe == "Paus"){
            Paus.elementos[p] = l.elementos[i];
            p++;
        }
    }


    mergeS(Ouro,0,o-1); // a ordena��o recursiva
    mergeS(Espadas,0,e-1);
    mergeS(Copas,0,c-1);
    mergeS(Paus,0,p-1);

    j=0;
    for (i=0; i<p; i++){
            if(Ouro.elementos[i].dado.naipe == "Ouro"){ //devolvendo pronto para  alista ordenada
                l.elementos[j]= Ouro.elementos[i];
                j++;
            }
    }

    for (i=0; i<e; i++){
                l.elementos[j]= Espadas.elementos[i];
                j++;
    }

    for (i=0; i<c; i++){
                l.elementos[j]= Copas.elementos[i];
                j++;
    }

    for (i=0; i<p; i++){
                l.elementos[j]= Paus.elementos[i];
                j++;
    }






}

template <typename TIPO, int MAX, typename TIPO2, int MAX2, typename TIPO3, int MAX3>
void distribuiCartas (Tlista <TIPO,MAX> &l, Tlista <TIPO2,MAX2> &m1, Tlista <TIPO2,MAX2> &m2, Tlista <TIPO2,MAX2> &m3,Tlista <TIPO3,MAX3> &mesa){

    int i;

    for(i=0;i<2;i++){
        insereInicio(m1,l.elementos[0].dado);
        removeInicio(l);

        cout << endl << "Mao 1: " << m1.elementos[0].dado.naipe;
        cout << endl << "Mao 1: " << m1.elementos[0].dado.valor;

        insereInicio(m2,l.elementos[0].dado);
        removeInicio(l);

        cout << endl << "Mao 2: " << m2.elementos[0].dado.naipe;
        cout << endl << "Mao 2: " << m2.elementos[0].dado.valor;

        insereInicio(m3,l.elementos[0].dado);
        removeInicio(l);

        cout << endl << "Mao 3: " << m3.elementos[0].dado.naipe;
        cout << endl << "Mao 3: " << m3.elementos[0].dado.valor;

    }

    for(i=0;i<5;i++){

        insereInicio(mesa,l.elementos[0].dado);
        removeInicio(l);

        cout << endl;
        cout << endl << "MESA: " << mesa.elementos[0].dado.naipe;
        cout << endl << "MESA: " << mesa.elementos[0].dado.valor;
        cout << endl;
    }

}

#endif // BARALHO_H_INCLUDED
