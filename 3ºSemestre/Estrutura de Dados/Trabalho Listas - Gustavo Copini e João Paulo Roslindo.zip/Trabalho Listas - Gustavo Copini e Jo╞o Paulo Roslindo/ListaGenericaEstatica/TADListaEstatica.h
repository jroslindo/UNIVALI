///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////Universidade do Vale do Itajai//////////////////////////////////////////////
/////////////Estrutura de Dados////////////////////////////////////////////////////////////////////
/////////////Professor: Rafael Ballotin////////////////////////////////////////////////////////////
/////////////Alunos: Jo�o Paulo Roslindo e Gustavo Copini Decol ///////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef TADLISTAESTATICA_H_INCLUDED
#define TADLISTAESTATICA_H_INCLUDED

template <typename TIPO>
struct TElemento{  //base de uma lista,  dado ser� lincado a TCarta

    TIPO dado;

};

template <typename TIPO, int MAX>  //criando a lista
struct Tlista{

    TElemento <TIPO> elementos[MAX];
    int quantidade;

};

template <typename TIPO, int MAX>
void inicializar(Tlista <TIPO,MAX> &l){ //inicializar a lista

    l.quantidade=0; //zera a quantidade para n ter lixo de memoria

}

template <typename TIPO, int MAX>
bool insereFinal(Tlista <TIPO,MAX> &l, TIPO dado){

    if(l.quantidade >= MAX){ //n�o pode inserir caso a quantidade passe do limite do baralho
        return false;
    }else{
        TElemento <TIPO> e; //cria um dado que ser� passado
        e.dado=dado; //atribui o dado
        l.elementos[l.quantidade]=e; // coloca o dado no final do vetor
        l.quantidade++; //incrementa quantidade
        return true;
    }
}

template <typename TIPO, int MAX>
bool removeFim(Tlista <TIPO,MAX> &l){

    if(l.quantidade == 0){ //n pode remover algo onde n�o existe nada
        return false;
    }else{
        l.quantidade--; // simplesmente decrementa quantidade, e assim perde-se o ultimo elemento, quando fizer uma inser��o por exemplo far� com que ele coloque o dado em cima desse antigo dado
        return true;
    }
}

template <typename TIPO, int MAX>
bool insereInicio(Tlista <TIPO,MAX> &l, TIPO dado){

    if(l.quantidade >= MAX){ //quantidade n pode passar do maximo
        return false;
    }else{
        int i;
        TElemento <TIPO> e; //cria o elemento q ser� inserido
        for(i=l.quantidade;i>0;i--){ // joga todo os elementos para o lado
            l.elementos[i]=l.elementos[i-1];
        }
        e.dado=dado;
        l.elementos[0]=e; //faz a inser��o no primeiro elemento
        l.quantidade++;
        return true;

    }
}

template <typename TIPO, int MAX>
bool removeInicio(Tlista <TIPO,MAX> &l){

    if(l.quantidade == 0){ //n pode remover algo onde n�o existe nada
        return false;
    }else{
        int i;
        for(i=1;i<l.quantidade;i++){ // joga todos os elementos para a esquerda e assim remove o primeiro elemento
            l.elementos[i-1]=l.elementos[i];
        }
        l.quantidade--; //decrementa a quantidade da lista
        return true;
    }

}

template <typename TIPO, int MAX>
bool inserePosi (Tlista <TIPO,MAX> &l, TIPO dado, int pos){

    if(l.quantidade >= MAX){
        return false;
    }else{
        int i;
        TElemento <TIPO> e; //o elemento
        for(i=l.quantidade;i>pos;i--){ //joga os elementos para o lado a partir da posi desejada
            l.elementos[i]=l.elementos[i-1];
        }
        e.dado=dado;
        l.elementos[pos]=e; //insere o dado na posi
        l.quantidade++;
        return true;
    }
}

template <typename TIPO, int MAX>
bool removePosi(Tlista <TIPO,MAX> &l, int pos){
    int i;

    if(l.quantidade == 0){
        return false;
    }else{
        if (pos == l.quantidade)
            removeFim(l);
        if (pos == 0)
            removeInicio(l);
        else{
        for(i=pos;i<l.quantidade-1;i++){ //puxa os elementos apagando a posi desejada
            l.elementos[i]=l.elementos[i+1];
        }
        l.quantidade--; //decrementa-se quantidade
        return true;
        }
    }

}


#endif // TADLISTAESTATICA_H_INCLUDED
